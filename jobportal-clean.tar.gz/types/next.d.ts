// Custom Next.js type augmentations (intentionally empty)
// Rely on official Next.js type definitions