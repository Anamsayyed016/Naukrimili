// Re-export from consolidated job-application.ts
export type { 
  JobApplication, 
  ApplicationStatus, 
  ApplicationFilters, 
  ApplicationStats, 
  ApplicationNote, 
  ApplicationTimeline 
} from './job-application';
