/**
 * Cache Busting Initializer Component
 * Ensures fresh JavaScript chunks are loaded on each deployment
 */

'use client';

import { useEffect } from 'react';
import { initializeCacheBusting } from '@/lib/cache-busting';

export default function CacheBustingInitializer() {
  useEffect(() => {
    // Initialize cache busting on component mount
    initializeCacheBusting();
    
    // Log build information for debugging - using dynamic import to avoid TDZ issues
    import('@/lib/cache-busting').then(({ BUILD_VERSION, BUILD_TIMESTAMP }) => {
      console.log('🚀 App initialized with build:', {
        version: BUILD_VERSION,
        timestamp: new Date(BUILD_TIMESTAMP).toISOString(),
        userAgent: navigator.userAgent
      });
    });
    
    // DISABLED: This was causing infinite reload loops
    // The chunk 4bd1b696 is still being generated in builds
    // Commenting out to prevent automatic reloads
    /*
    const checkForOldChunks = () => {
      const scripts = document.querySelectorAll('script[src]');
      scripts.forEach(script => {
        const src = script.getAttribute('src');
        if (src && src.includes('4bd1b696-100b9d70ed4e49c1.js')) {
          console.warn('🚨 Detected old problematic chunk:', src);
          // Force reload to get fresh chunks
          setTimeout(() => {
            window.location.reload();
          }, 1000);
        }
      });
    };
    
    // Run check after a short delay to ensure all scripts are loaded
    setTimeout(checkForOldChunks, 2000);
    */
    
  }, []);

  // This component doesn't render anything
  return null;
}