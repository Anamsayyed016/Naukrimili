import { NextRequest, NextResponse } from 'next/server';

export async function GET(_request: NextRequest) {
  return NextResponse.json({ 
    success: true, 
    message: 'API endpoint working' 
  });
}

export async function POST(_request: NextRequest) {
  try {
    const body = await _request.json();
    return NextResponse.json({ 
      success: true, 
      data: body 
    });
    } catch {
    return NextResponse.json({ 
      success: false, 
      error: 'Invalid request' 
    }, { status: 400 });
  }
}
