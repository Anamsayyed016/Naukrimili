'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  ArrowLeft, 
  Download, 
  Mail, 
  Phone, 
  MapPin, 
  Briefcase, 
  Building2,
  FileText,
  User,
  Calendar,
  CheckCircle,
  XCircle,
  Clock
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import Link from 'next/link';

// Helper function to normalize skills (handle string, array, or null)
function normalizeSkills(skills: unknown): string[] {
  if (!skills) return [];
  if (Array.isArray(skills)) return skills.filter(skill => skill && typeof skill === 'string');
  if (typeof skills === 'string') {
    try {
      const parsed = JSON.parse(skills);
      if (Array.isArray(parsed)) {
        return parsed.filter(skill => skill && typeof skill === 'string');
      }
      // If it's a comma-separated string
      if (skills.includes(',')) {
        return skills.split(',').map(s => s.trim()).filter(s => s.length > 0);
      }
      // Single skill string
      return skills.trim() ? [skills.trim()] : [];
    } catch {
      // Not JSON, treat as comma-separated or single string
      if (skills.includes(',')) {
        return skills.split(',').map(s => s.trim()).filter(s => s.length > 0);
      }
      return skills.trim() ? [skills.trim()] : [];
    }
  }
  return [];
}

interface ApplicationDetail {
  id: string;
  status: string;
  appliedAt: string;
  coverLetter?: string;
  user: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
    location?: string;
    profilePicture?: string;
    bio?: string;
    skills?: string[];
    experience?: string;
    education?: string;
  };
  job: {
    id: string;
    title: string;
    company: string;
    location: string;
    description?: string;
    salary?: number;
    salaryMin?: number;
    salaryMax?: number;
    salaryCurrency?: string;
    jobType?: string;
    experienceLevel?: string;
  };
  resume?: {
    id: string;
    fileName: string;
    fileUrl: string;
    fileSize?: number;
    mimeType?: string;
    atsScore?: number;
  } | null;
  company?: {
    id: string;
    name: string;
    logo?: string;
    website?: string;
    location?: string;
  } | null;
}

export default function ApplicationDetailPage() {
  const params = useParams();
  const router = useRouter();
  const applicationId = params.id as string;
  
  const [application, setApplication] = useState<ApplicationDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  const fetchApplication = React.useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/admin/applications/${applicationId}`);
      
      if (!response.ok) {
        if (response.status === 404) {
          toast({
            title: "Application not found",
            description: "This application does not exist or has been deleted.",
            variant: "destructive",
          });
          router.push('/admin/applications');
          return;
        }
        throw new Error('Failed to fetch application');
      }

      const result = await response.json();
      if (result.success && result.data) {
        // Normalize skills to ensure it's always an array
        const normalizedData = {
          ...result.data,
          user: {
            ...result.data.user,
            skills: normalizeSkills(result.data.user.skills)
          }
        };
        setApplication(normalizedData);
      } else {
        throw new Error(result.error || 'Failed to load application');
      }
    } catch (error) {
      console.error('Error fetching application:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to load application details",
        variant: "destructive",
      });
      router.push('/admin/applications');
    } finally {
      setLoading(false);
    }
  }, [applicationId, router]);

  useEffect(() => {
    if (applicationId) {
      fetchApplication();
    }
  }, [applicationId, fetchApplication]);

  const handleStatusChange = async (newStatus: string) => {
    if (!application) return;
    
    try {
      setUpdating(true);
      const response = await fetch(`/api/admin/applications/${applicationId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });

      if (response.ok) {
        setApplication({ ...application, status: newStatus });
        toast({
          title: "Success",
          description: "Application status updated successfully",
        });
      } else {
        throw new Error('Failed to update status');
      }
    } catch (error) {
      console.error('Error updating application status:', error);
      toast({
        title: "Error",
        description: "Failed to update application status",
        variant: "destructive",
      });
    } finally {
      setUpdating(false);
    }
  };

  const handleDownloadResume = async () => {
    if (!application?.resume) return;
    
    try {
      const response = await fetch(`/api/admin/resumes/${application.resume.id}/download`);
      
      if (!response.ok) {
        throw new Error('Failed to download resume');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = application.resume.fileName || 'resume.pdf';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error downloading resume:', error);
      toast({
        title: "Error",
        description: "Failed to download resume",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: { variant: 'secondary' as const, label: 'Pending', icon: Clock },
      reviewed: { variant: 'default' as const, label: 'Reviewed', icon: CheckCircle },
      shortlisted: { variant: 'default' as const, label: 'Shortlisted', icon: CheckCircle },
      rejected: { variant: 'destructive' as const, label: 'Rejected', icon: XCircle },
      hired: { variant: 'default' as const, label: 'Hired', icon: CheckCircle }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    const Icon = config.icon;
    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <Icon className="h-3 w-3" />
        {config.label}
      </Badge>
    );
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading application details...</p>
        </div>
      </div>
    );
  }

  if (!application) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-gray-500 mb-4">Application not found</p>
            <Link href="/admin/applications">
              <Button>Back to Applications</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
      <div className="mb-4 sm:mb-6">
        <Link href="/admin/applications">
          <Button variant="ghost" className="mb-3 sm:mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Applications
          </Button>
        </Link>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4">
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Application Details</h1>
            <p className="text-sm sm:text-base text-gray-600 mt-1">Review and manage this job application</p>
          </div>
          <div className="flex items-center gap-2 sm:gap-3 w-full sm:w-auto">
            {getStatusBadge(application.status)}
            <Select
              value={application.status}
              onValueChange={handleStatusChange}
              disabled={updating}
            >
              <SelectTrigger className="w-full sm:w-40 min-w-0">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="reviewed">Reviewed</SelectItem>
                <SelectItem value="shortlisted">Shortlisted</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="hired">Hired</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-5 lg:gap-6">
        {/* Left Column - Applicant & Job Info */}
        <div className="lg:col-span-2 space-y-4 sm:space-y-5 lg:space-y-6">
          {/* Applicant Information */}
          <Card>
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <User className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
                Applicant Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
              <div>
                <h3 className="font-semibold text-base sm:text-lg break-words">
                  {application.user.firstName && application.user.lastName
                    ? `${application.user.firstName} ${application.user.lastName}`
                    : application.user.email}
                </h3>
                <div className="flex flex-col sm:flex-row sm:flex-wrap gap-2 sm:gap-3 md:gap-4 mt-2 text-xs sm:text-sm text-gray-600">
                  {application.user.email && (
                    <div className="flex items-center gap-2 min-w-0">
                      <Mail className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                      <span className="truncate">{application.user.email}</span>
                    </div>
                  )}
                  {application.user.phone && (
                    <div className="flex items-center gap-2 min-w-0">
                      <Phone className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                      <span className="truncate">{application.user.phone}</span>
                    </div>
                  )}
                  {application.user.location && (
                    <div className="flex items-center gap-2 min-w-0">
                      <MapPin className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                      <span className="truncate">{application.user.location}</span>
                    </div>
                  )}
                </div>
              </div>

              {application.user.bio && (
                <div>
                  <h4 className="font-medium mb-2 text-sm sm:text-base">About</h4>
                  <p className="text-gray-600 text-xs sm:text-sm break-words">{application.user.bio}</p>
                </div>
              )}

              {(() => {
                // Safely handle skills - could be array, string, or null
                let skillsArray: string[] = [];
                if (application.user.skills) {
                  if (Array.isArray(application.user.skills)) {
                    skillsArray = application.user.skills.filter(skill => skill && typeof skill === 'string');
                  } else if (typeof application.user.skills === 'string') {
                    try {
                      const parsed = JSON.parse(application.user.skills);
                      skillsArray = Array.isArray(parsed) ? parsed.filter((s: unknown) => s && typeof s === 'string') : [];
                    } catch {
                      // Not JSON, try comma-separated
                      const skillsStr = typeof application.user.skills === 'string' ? application.user.skills : '';
                      if (skillsStr.includes(',')) {
                        skillsArray = skillsStr.split(',').map(s => s.trim()).filter(s => s.length > 0);
                      } else if (skillsStr.trim()) {
                        skillsArray = [skillsStr.trim()];
                      }
                    }
                  }
                }
                
                return skillsArray.length > 0 ? (
                  <div>
                    <h4 className="font-medium mb-2 text-sm sm:text-base">Skills</h4>
                    <div className="flex flex-wrap gap-1.5 sm:gap-2">
                      {skillsArray.map((skill, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">{String(skill)}</Badge>
                      ))}
                    </div>
                  </div>
                ) : null;
              })()}

              {application.user.experience && (
                <div>
                  <h4 className="font-medium mb-2 text-sm sm:text-base">Experience</h4>
                  <p className="text-gray-600 text-xs sm:text-sm whitespace-pre-wrap break-words">{application.user.experience}</p>
                </div>
              )}

              {application.user.education && (
                <div>
                  <h4 className="font-medium mb-2 text-sm sm:text-base">Education</h4>
                  <p className="text-gray-600 text-xs sm:text-sm whitespace-pre-wrap break-words">{application.user.education}</p>
                </div>
              )}

              {application.resume && (
                <div className="pt-3 sm:pt-4 border-t">
                  <Button onClick={handleDownloadResume} className="w-full sm:w-auto text-xs sm:text-sm">
                    <Download className="h-3 w-3 sm:h-4 sm:w-4 mr-2" />
                    Download Resume
                  </Button>
                  <p className="text-[10px] sm:text-xs text-gray-500 mt-2 break-all">
                    {application.resume.fileName} 
                    {application.resume.fileSize && ` • ${(application.resume.fileSize / 1024).toFixed(2)} KB`}
                    {application.resume.atsScore && ` • ATS Score: ${application.resume.atsScore}%`}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Job Information */}
          <Card>
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Briefcase className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
                Job Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
              <div>
                <h3 className="font-semibold text-base sm:text-lg break-words">{application.job.title}</h3>
                <div className="flex flex-col sm:flex-row sm:flex-wrap gap-2 sm:gap-3 md:gap-4 mt-2 text-xs sm:text-sm text-gray-600">
                  <div className="flex items-center gap-2 min-w-0">
                    <Building2 className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                    <span className="truncate">{application.job.company}</span>
                  </div>
                  <div className="flex items-center gap-2 min-w-0">
                    <MapPin className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                    <span className="truncate">{application.job.location}</span>
                  </div>
                  {application.job.jobType && (
                    <Badge variant="outline" className="text-xs w-fit">{application.job.jobType}</Badge>
                  )}
                  {application.job.experienceLevel && (
                    <Badge variant="outline" className="text-xs w-fit">{application.job.experienceLevel}</Badge>
                  )}
                </div>
              </div>

              {(application.job.salaryMin || application.job.salaryMax) && (
                <div>
                  <h4 className="font-medium mb-1 text-sm sm:text-base">Salary</h4>
                  <p className="text-gray-600 text-xs sm:text-sm">
                    {application.job.salaryCurrency || '₹'}
                    {application.job.salaryMin?.toLocaleString()}
                    {application.job.salaryMax && application.job.salaryMin !== application.job.salaryMax && (
                      <> - {application.job.salaryMax.toLocaleString()}</>
                    )}
                  </p>
                </div>
              )}

              {application.job.description && (
                <div>
                  <h4 className="font-medium mb-2 text-sm sm:text-base">Job Description</h4>
                  <p className="text-gray-600 text-xs sm:text-sm whitespace-pre-wrap break-words">{application.job.description}</p>
                </div>
              )}

              <Link href={`/jobs/${(application.job as Record<string, unknown>).sourceId || application.job.id}`}>
                <Button variant="outline" className="w-full sm:w-auto text-xs sm:text-sm">
                  <Briefcase className="h-3 w-3 sm:h-4 sm:w-4 mr-2" />
                  View Job Posting
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Cover Letter */}
          {application.coverLetter && (
            <Card>
              <CardHeader className="p-4 sm:p-6">
                <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                  <FileText className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
                  Cover Letter
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 sm:p-6">
                <p className="text-gray-600 text-xs sm:text-sm whitespace-pre-wrap break-words">{application.coverLetter}</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right Column - Application Details */}
        <div className="space-y-4 sm:space-y-5 lg:space-y-6">
          <Card>
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Calendar className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
                Application Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
              <div>
                <p className="text-xs sm:text-sm text-gray-500 mb-1">Applied On</p>
                <p className="font-medium text-xs sm:text-sm break-words">
                  {new Date(application.appliedAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </p>
              </div>

              <div>
                <p className="text-xs sm:text-sm text-gray-500 mb-1">Application ID</p>
                <p className="font-mono text-[10px] sm:text-xs text-gray-700 break-all">{application.id}</p>
              </div>

              {application.resume && (
                <div>
                  <p className="text-xs sm:text-sm text-gray-500 mb-1">Resume</p>
                  <div className="flex items-center gap-2 min-w-0">
                    <FileText className="h-3 w-3 sm:h-4 sm:w-4 text-gray-400 flex-shrink-0" />
                    <span className="text-xs sm:text-sm text-gray-700 truncate">{application.resume.fileName}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Actions */}
          <Card>
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="text-base sm:text-lg">Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 p-4 sm:p-6">
              {application.resume && (
                <Button onClick={handleDownloadResume} className="w-full text-xs sm:text-sm" variant="outline">
                  <Download className="h-3 w-3 sm:h-4 sm:w-4 mr-2" />
                  Download Resume
                </Button>
              )}
              <Link href={`/jobs/${(application.job as Record<string, unknown>).sourceId || application.job.id}`}>
                <Button variant="outline" className="w-full text-xs sm:text-sm">
                  <Briefcase className="h-3 w-3 sm:h-4 sm:w-4 mr-2" />
                  View Job
                </Button>
              </Link>
              <Link href={`/admin/users/${application.user.id}`}>
                <Button variant="outline" className="w-full text-xs sm:text-sm">
                  <User className="h-3 w-3 sm:h-4 sm:w-4 mr-2" />
                  View Applicant Profile
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
